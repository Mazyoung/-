
//import com.sun.tools.javac.Main;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.LinkedList;
import java.util.Timer;
import java.util.TimerTask;

public class Frame extends JFrame implements KeyListener {
    private Timer timer;
    Snake snake = new Snake();
    Painter painter = new Painter();
    Label label = new Label();
    static Frame gui = new Frame();
    static Frame gui2 = new Frame();
    public void setFrame() {
        ImageIcon imageIcon=new ImageIcon("images/snake.png");
        this.setIconImage(imageIcon.getImage());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.getContentPane().add(label);
        this.getContentPane().add(painter);
        label.setBounds(10,10,100,30);
        this.setVisible(true);
        this.setBounds(650, 200, 600, 609);
        this.setTitle("贪吃蛇~");
        this.addKeyListener(this);
        initTimer();
    }
    public  void setFrame2(){
        Ranker ranker = new Ranker();
        ranker.addScore(snake.getScore());
        ranker.rank();
        JLabel label = new JLabel();
        JButton button = new JButton("按按钮后按w重新开始");
        button.addActionListener(new ButtonListener());
        Font font = new Font("仿宋", Font.PLAIN, 30);
        label.setFont(font);
        label.setForeground(new Color(0,0,0));
        ImageIcon imageIcon=new ImageIcon("images/snake.png");
        gui2.setIconImage(imageIcon.getImage());
        gui2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gui2.getContentPane().add(BorderLayout.CENTER,label);
        gui2.getContentPane().add(BorderLayout.WEST,button);
        button.setBounds(500,50,60,20);
        label.setBounds(10,10,600,600);
        gui2.setVisible(true);
        gui2.setBounds(650, 200, 600, 609);
        gui2.setTitle("排行榜~");
        int a1 = ranker.get1();
        int a2 = ranker.get2();
        int a3 = ranker.get3();
        int a4 = ranker.get4();
        label.setText("<html><p>第一名:"+a1+"</p><p>第二名:"+a2+"</p><p>第三名:"+a3+"</p>第四名:"+a4);
    }
    class ButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            gui.setVisible(true);
            gui2.setVisible(false);
        }
    }
    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_S:
                snake.setLiving(false);
                break;
            case KeyEvent.VK_W:
                snake.setLiving(true);
                snake.initSnake();
                initTimer();
                break;
            case KeyEvent.VK_UP:
                if (snake.getDirection() != 1) {
                    snake.setDirection(0);
                }
                break;
            case KeyEvent.VK_DOWN:
                if (snake.getDirection() != 0) {
                    snake.setDirection(1);
                }
                break;
            case KeyEvent.VK_LEFT:
                if (snake.getDirection() != 3) {
                    snake.setDirection(2);
                }
                break;
            case KeyEvent.VK_RIGHT:
                if (snake.getDirection() != 2) {
                    snake.setDirection(3);
                }
                break;
        }
        this.repaint();
    }//键盘监听

    @Override
    public void keyReleased(KeyEvent e) {

    }

    private void initTimer() {

        timer = new Timer();

        TimerTask timerTask1 = new TimerTask() {
            @Override
            public void run() {
                snake.move();
                snake.eatFood();
                painter.repaint();
                label.setText(String.valueOf(snake.getScore()));
                if (snake.getIsLiving() == false){
                    Frame gui2 =new Frame();
                    Ranker ranker = new Ranker();
                    ranker.addScore(snake.getScore());
                    ranker.rank();
                    JLabel label = new JLabel();
                    JButton button = new JButton("按按钮后按w重新开始");
                    button.addActionListener(new ButtonListener());
                    Font font = new Font("仿宋", Font.PLAIN, 30);
                    label.setFont(font);
                    label.setForeground(new Color(0,0,0));
                    ImageIcon imageIcon=new ImageIcon("images/snake.png");
                    gui2.setIconImage(imageIcon.getImage());
                    gui2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    gui2.getContentPane().add(BorderLayout.CENTER,label);
                    gui2.getContentPane().add(BorderLayout.WEST,button);
                    button.setBounds(500,50,60,20);
                    label.setBounds(10,10,600,600);
                    gui2.setVisible(true);
                    gui2.setBounds(650, 200, 600, 609);
                    gui2.setTitle("排行榜~");
                    int a1 = ranker.get1();
                    int a2 = ranker.get2();
                    int a3 = ranker.get3();
                    int a4 = ranker.get4();
                    label.setText("<html><p>第一名:"+a1+"</p><p>第二名:"+a2+"</p><p>第三名:"+a3+"</p>第四名:"+a4);
                    gui.setVisible(false);
                    timer.cancel();
                }
                if (snake.getSize() > 10) {
                    snake.setA(200);
                    timer.cancel();
                    Timer timer2 = new Timer();
                    TimerTask timerTask1 = new TimerTask() {
                    public void run () {
                        snake.move();
                        snake.eatFood();
                        painter.repaint();
                        label.setText(String.valueOf(snake.getScore()));
                        if (snake.getIsLiving() == false){
                            Frame gui2 =new Frame();
                            Ranker ranker = new Ranker();
                            ranker.addScore(snake.getScore());
                            ranker.rank();
                            JLabel label = new JLabel();
                            JButton button = new JButton("按按钮后按w重新开始");
                            button.addActionListener(new ButtonListener());
                            Font font = new Font("仿宋", Font.PLAIN, 30);
                            label.setFont(font);
                            label.setForeground(new Color(0,0,0));
                            ImageIcon imageIcon=new ImageIcon("images/snake.png");
                            gui2.setIconImage(imageIcon.getImage());
                            gui2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                            gui2.getContentPane().add(BorderLayout.CENTER,label);
                            gui2.getContentPane().add(BorderLayout.WEST,button);
                            button.setBounds(500,50,60,20);
                            label.setBounds(10,10,600,600);
                            gui2.setVisible(true);
                            gui2.setBounds(650, 200, 600, 609);
                            gui2.setTitle("排行榜~");
                            int a1 = ranker.get1();
                            int a2 = ranker.get2();
                            int a3 = ranker.get3();
                            int a4 = ranker.get4();
                            label.setText("<html><p>第一名:"+a1+"</p><p>第二名:"+a2+"</p><p>第三名:"+a3+"</p>第四名:"+a4);
                            gui.setVisible(false);
                            timer2.cancel();
                        }
                    }
                    };timer2.scheduleAtFixedRate(timerTask1, 0, 70);

                }
            }

        };

        timer.scheduleAtFixedRate(timerTask1, 0, 100);
    }
//谜一样滴计时器

    public class Painter extends JPanel{
        public void paint(Graphics g) {
            g.clearRect(0,0,600,609);//刷新jpanel
            g.setColor(Color.black);
            LinkedList<Node> body = snake.getBody();
            for(Node node : body) {
                g.fillRect(node.getX()*15, node.getY()*15, 15, 15);
                //画小蛇
                g.fillRect(snake.getX()*15,snake.getY()*15,15,15);
                //食物
            }
        }
    }

    public static void main(String[] args) {
        gui.setFrame();
    }
}







