
import java.util.LinkedList;

public class Snake {

    private int score = 0;
    private int a = 100;
    private int direction = 1;
    // 0表示向上
    // 1向下
    // 2向左
    // 3向右
    private boolean isLiving = false;

    int x = (int) (Math.random() * 40 );
    int y = (int) (Math.random() * 35 + 2);
    public void random(){
        x = (int) (Math.random() * 40 );
        y = (int) (Math.random() * 35 + 2);
    }//随机食物的刷新位置
    Node food = new Node(x,y);
    private LinkedList<Node> body;
    public Snake() {
        initSnake();
        isLiving = true;
    }

    public void setLiving(boolean isLiving) {
        this.isLiving=isLiving;
    }

    public int getScore() {
        return score;
    }

    public void setA(int a) {
        this.a = a;
    }
    public boolean getIsLiving(){
        return isLiving;
    }
    public int getSize(){
        return body.size();
    }
    public void restart(){
        score = 0;
        initSnake();
        direction = 1;
        isLiving = true;

    }
    public void initSnake() {
        body = new LinkedList<>();
        body.add(new Node(1,5));
        body.add(new Node(1,4));
        body.add(new Node(1,3));
        body.add(new Node(1,2));
        body.add(new Node(1,1));//初始化小蛇~
    }

    public void move() {
        if (isLiving) {
            Node head = body.getFirst();
            switch (direction) {
                case 0:
                    body.addFirst(new Node(head.getX(), head.getY() - 1));
                    break;
                case 1:
                    body.addFirst(new Node(head.getX(), head.getY() + 1));
                    break;
                case 2:
                    body.addFirst(new Node(head.getX() - 1, head.getY()));
                    break;
                case 3:
                    body.addFirst(new Node(head.getX() + 1, head.getY()));
                    break;
            }
            body.removeLast();//让蛇动起来
            head = body.getFirst();//重置新的蛇头

                for (Node node : body) {
                    if (head.getX() < 0) node.setX(38);
                    if (head.getX() >= 39) node.setX(0);
                    if (head.getY() < 0) node.setY(37);
                    if (head.getY() >= 38) node.setY(0);
                }//判断是否到边缘

            for (int i = 1; i < body.size()-1; i++) {
                Node node = body.get(i);
                if (head.getX() == node.getX() && head.getY() == node.getY()) {
                    isLiving = false;
                }//判断是否碰到自己
            }
        }
    }
    public void eatFood(){
        Node head = body.getFirst();
        if (head.getX() == x && head.getY()==y){
            switch (direction){
                case 0:
                    body.addFirst(new Node(head.getX(),head.getY()-1));
                    break;
                case 1:
                    body.addFirst(new Node(head.getX(),head.getY()+1));
                    break;
                case 2:
                    body.addFirst(new Node(head.getX()-1,head.getY()));
                    break;
                case 3:
                    body.addFirst(new Node(head.getX()+1,head.getY()));
                    break;//在蛇头附件加新节点
            }
            random();//随机刷新新食物
            score = score+a;
        }


    }

    public int getDirection() {
        return direction;
    }

    public void setDirection(int direction) {
        this.direction = direction;
    }
    public LinkedList getBody(){

        return body;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}

