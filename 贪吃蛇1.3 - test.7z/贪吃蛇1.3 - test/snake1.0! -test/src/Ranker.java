import java.util.ArrayList;

public class Ranker {
    ArrayList<Integer> a = new ArrayList<Integer>();
    int b,i;
    public void addScore(int score) {
        a.add(score);
        a.add(1);
        a.add(2);
        a.add(3);
        a.add(4);
    }
    public void rank(){
        if(a.size()>1) {
            for (i = 0; i < a.size() - 1; i++) {
                if (a.get(i) > a.get(i + 1)) {
                    b = a.get(i);
                    a.set(i, a.get(i + 1));
                    a.set(i + 1, b);
                }
            }
        }else if(a.size()>2) {
            for (i = 0; i < a.size() - 2; i++) {
                if (a.get(i) > a.get(i + 1)) {
                    b = a.get(i);
                    a.set(i, a.get(i + 1));
                    a.set(i + 1, b);
                }
            }
        }
        else if(a.size()>3) {
            for (i = 0; i < a.size() - 3; i++) {
                if (a.get(i) > a.get(i + 1)) {
                    b = a.get(i);
                    a.set(i, a.get(i + 1));
                    a.set(i + 1, b);
                }
            }
        }
        else if(a.size()>4) {
            for (i = 0; i < a.size() - 4; i++) {
                if (a.get(i) > a.get(i + 1)) {
                    b = a.get(i);
                    a.set(i, a.get(i + 1));
                    a.set(i + 1, b);
                }
            }
        }
    }
    public int get1(){
        return (a.get(a.size()-1));
    }
    public int get2(){
        return (a.get(a.size()-2));
    }
    public int get3(){
        return (a.get(a.size()-3));
    }
    public int get4(){
        return (a.get(a.size()-4));
    }

}
