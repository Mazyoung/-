import java.io.File;

public class Text {
    File file = new File("images/排行榜.text");
    StringBuilder stringBuilder = new StringBuilder();
}
